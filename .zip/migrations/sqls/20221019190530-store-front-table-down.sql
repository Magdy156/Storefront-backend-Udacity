/* Replace with your SQL commands */
DROP TABLE if exists users cascade;
DROP TABLE if exists products cascade;
DROP TABLE if exists orders cascade;
DROP TABLE if exists order_products cascade;
